package com.fariki.theworkshop;

import android.content.Intent;
import android.support.v7.app.AppCompatActivity;
import android.os.Bundle;
import android.support.v7.widget.Toolbar;
import android.view.View;

public class MainActivity extends AppCompatActivity {
    Toolbar toolbar;
    View view;

    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        setContentView(R.layout.activity_main);
        getSupportActionBar().hide();
        init();
    }

    public void init(){
    }

    public void menuMaster(View view) {
        Intent intent = new Intent(this,ActivityMaster.class);
        startActivity(intent);
    }

    public void menuTransaction(View view) {
        Intent intent = new Intent(this,ActivityTransaction.class);
        startActivity(intent);
    }

    public void menuSetting(View view) {
        Intent intent = new Intent(this,ActivitySetting.class);
        startActivity(intent);
    }

    public void menuReport(View view) {
        Intent intent = new Intent(this,ActivityReport.class);
        startActivity(intent);
    }
}
